$(function(){
$(window).on('scroll',function(){
var scroll = $(window).screenTop();
if(scroll>=50){
    $('.hamburger').addClass('whenscrolled')
    $('nav').addClass('stickyadd');
    $('nav').removeClass('stick');

}
else{
    $('.hamburger').removeClass('whenscrolled')
    $('nav').removeClass('stickyadd');  
    $('nav').addClass('stick');
}
})
$('.navbar-nav a[href^="#"]').on('click',function(event))({
    event.preventDefault();
    $('html','body').animate({
        scrollTop:$(this.hash).offset().top
    },1000);
})
});